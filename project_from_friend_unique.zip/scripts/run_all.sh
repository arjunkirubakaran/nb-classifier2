
#!/usr/bin/env bash
set -euo pipefail
# Example end-to-end (edit the TGZ path)
python bin/prepare_data.py --tar_gz 20_newsgroups.tar.gz --out data --seed 42
python main.py --data_root data --alpha 1.0 --report reports/report.md
echo "Report written to reports/report.md"
