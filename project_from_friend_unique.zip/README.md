
# Project 2 — From-Scratch Naive Bayes Text Classifier (Student Version)

This repository provides a **from-scratch Multinomial Naive Bayes** implementation to classify the **20 Newsgroups** dataset.
It includes a data-prep utility to **extract & 50/50 split** the dataset, a training script, metrics, and a generated report.

> **Important:** The code is original (no external ML libraries, no copy of online NB code).

---

## Quick Start

### 1) Prepare the data

Option A: pass the tarball and let the tool extract + split:
```bash
python bin/prepare_data.py --tar_gz /path/to/20_newsgroups.tar.gz --out data --seed 42
```

Option B: if you already extracted it and have the 20 class folders:
```bash
python bin/prepare_data.py --extracted_root /path/to/20_newsgroups --out data --seed 42
```

This will create:
```
data/
  train/<20 class folders>
  test/<20 class folders>
```

### 2) Train & Evaluate

```bash
python main.py --data_root data --alpha 1.0 --report reports/report.md
```

The script prints accuracy and writes a **`reports/report.md`** with confusion matrix and per-class metrics.

---

## Structure

```
project2_nb_script/
  main.py
  report_template.md
  README.md
  bin/
    prepare_data.py
  src/
    data/
      io.py
    text/
      processing.py
    model/
      nb.py
    eval/
      metrics.py
  data/     # created by prepare_data.py
  reports/  # report output
```

---

## Implementation Notes

- **Tokenizer:** lowercase + alphanumeric; simple stopword removal.
- **Model:** Multinomial Naive Bayes with Laplace smoothing (configurable `--alpha`).
- **Split:** 50/50 per class with fixed seed (default 42) for reproducibility.
- **No online code reused.**

---

## Hand-in Guidance

- Include this **code** and the **data** (after you run the splitter) in a single submission, so the TA can simply run:
```bash
python main.py --data_root data --alpha 1.0 --report reports/report.md
```
