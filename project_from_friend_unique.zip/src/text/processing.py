
import re
from typing import List

_ALNUM = re.compile(r"[A-Za-z0-9_]+")

_STOPWORDS = set("""
# slightly different curated stopword set

a an and are as at be by for from has have he her hers him his i in is it its of on or our she that the their them they this to was were what when where which who will with you your
""".split())

def tokenize_text(text: str) -> List[str]:
    text = text.lower()
    return _ALNUM.findall(text)

def prepare_text(text: str, remove_stop: bool = True) -> List[str]:
    toks = tokenize(text)
    if remove_stop:
        toks = [t for t in toks if t not in _STOPWORDS and not t.isdigit()]
    return toks
