
# Project 2 — Student Naive Bayes Report (Unique Submission)

**Run:** {timestamp}

## Setup
- Smoothing alpha: **{alpha}**
- Vocabulary size: **{vocab}**
- Train examples: **{ntrain}**
- Test examples: **{ntest}**
- Classes: {classes}

## Results
- **Accuracy:** {accuracy}
- **Macro F1:** {macro_f1}
- **Micro F1:** {micro_f1}

### Confusion Matrix (TSV)
```
{cm_tsv}
```

### Per-Class Metrics (JSON)
```json
{per_class}
```

## Implementation Notes and Differences
This implementation uses a simple tokenizer (lowercase + alphanumeric) and Laplace smoothing. You can adjust stopword removal or alpha to observe changes in performance.

## Reproduce
```bash
# 1) Prepare data (either pass a tar.gz or an extracted folder)
python bin/prepare_data.py --tar_gz /path/to/20_newsgroups.tar.gz --out data --seed 42
# or
python bin/prepare_data.py --extracted_root /path/to/20_newsgroups --out data --seed 42

# 2) Train & Evaluate and write report
python main.py --data_root data --alpha 1.0 --report reports/report.md
```
